﻿using System;

namespace DecoderRing
{
    public class InvalidCharacterException : Exception
    {
        public InvalidCharacterException() : base("INVALID CHARACTER")
        {
        }

        public InvalidCharacterException(string message) : base(message)
        {
        }
    }
}
