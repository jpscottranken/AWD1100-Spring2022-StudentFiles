﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DecoderRing
{
    public partial class DecoderForm : Form
    {
        public DecoderForm()
        {
            InitializeComponent();
            lblInputError.Text = "";
            lblOutputError.Text = "";
            lblShiftError.Text = "";
        }

        private void btnEncode_Click(object sender, EventArgs e)
        {
            lblInputError.Text = "";
            lblOutputError.Text = "";
            lblShiftError.Text = "";

            var ring = new DecoderRing();
            ring.Shift = int.Parse(txtShift.Text);

            try
            {
                txtOutput.Text = ring.Encode(txtInput.Text);
            }
            catch (InvalidCharacterException ex)
            {
                lblInputError.Text = ex.Message;
            }
        }
    }
}
