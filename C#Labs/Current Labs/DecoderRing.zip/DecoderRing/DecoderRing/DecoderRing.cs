﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoderRing
{
    public class DecoderRing
    {
        private int _shift = 0;
        private string _innerRing = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        private string _outerRing = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        public DecoderRing() {}

        public int Shift
        {
            get { return _shift; }
            set { _shift = value; }
        }

        public string Encode(string text)
        {
            StringBuilder results = new StringBuilder();
            for (int i = 0; i < text.Length; ++i)
            {
                results.Append(EncodeChar(text[i]));
            }
            return results.ToString();
        }

        private char EncodeChar(char c)
        {
            if (char.IsWhiteSpace(c))
            {
                return c;
            }
            if (char.IsLetter(c))
            {
                for (int i = 0; i < _innerRing.Length; ++i)
                {
                    if (char.ToUpper(c) == _innerRing[i])
                    {
                        return _outerRing[(i + _shift) % 26];
                    }
                }
                throw new InvalidCharacterException($"{c} is invalid");

                //int index = char.ToUpper(c) - 'A';
                //return _outerRing[(index + _shift) % 26];
            }
            else
            {
                throw new InvalidCharacterException($"{c} is invalid");
            }
        }
    }
}
