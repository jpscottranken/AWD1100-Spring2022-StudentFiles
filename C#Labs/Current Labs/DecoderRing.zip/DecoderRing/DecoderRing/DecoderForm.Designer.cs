﻿namespace DecoderRing
{
    partial class DecoderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.btnEncode = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblInputError = new System.Windows.Forms.Label();
            this.lblOutput = new System.Windows.Forms.Label();
            this.lblOutputError = new System.Windows.Forms.Label();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.lblShift = new System.Windows.Forms.Label();
            this.txtShift = new System.Windows.Forms.TextBox();
            this.lblShiftError = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // btnEncode
            // 
            this.btnEncode.Location = new System.Drawing.Point(610, 23);
            this.btnEncode.Name = "btnEncode";
            this.btnEncode.Size = new System.Drawing.Size(75, 23);
            this.btnEncode.TabIndex = 6;
            this.btnEncode.Text = "Encode";
            this.btnEncode.UseVisualStyleBackColor = true;
            this.btnEncode.Click += new System.EventHandler(this.btnEncode_Click);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(12, 25);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(446, 20);
            this.txtInput.TabIndex = 1;
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Location = new System.Drawing.Point(12, 9);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(31, 13);
            this.lblInput.TabIndex = 0;
            this.lblInput.Text = "Input";
            // 
            // lblInputError
            // 
            this.lblInputError.AutoSize = true;
            this.lblInputError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInputError.ForeColor = System.Drawing.Color.Red;
            this.lblInputError.Location = new System.Drawing.Point(15, 48);
            this.lblInputError.Name = "lblInputError";
            this.lblInputError.Size = new System.Drawing.Size(33, 13);
            this.lblInputError.TabIndex = 2;
            this.lblInputError.Text = "error";
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Location = new System.Drawing.Point(9, 84);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(39, 13);
            this.lblOutput.TabIndex = 7;
            this.lblOutput.Text = "Output";
            // 
            // lblOutputError
            // 
            this.lblOutputError.AutoSize = true;
            this.lblOutputError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutputError.ForeColor = System.Drawing.Color.Red;
            this.lblOutputError.Location = new System.Drawing.Point(15, 123);
            this.lblOutputError.Name = "lblOutputError";
            this.lblOutputError.Size = new System.Drawing.Size(33, 13);
            this.lblOutputError.TabIndex = 9;
            this.lblOutputError.Text = "error";
            // 
            // txtOutput
            // 
            this.txtOutput.Location = new System.Drawing.Point(12, 100);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(446, 20);
            this.txtOutput.TabIndex = 8;
            // 
            // lblShift
            // 
            this.lblShift.AutoSize = true;
            this.lblShift.Location = new System.Drawing.Point(494, 9);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(28, 13);
            this.lblShift.TabIndex = 3;
            this.lblShift.Text = "Shift";
            // 
            // txtShift
            // 
            this.txtShift.Location = new System.Drawing.Point(494, 25);
            this.txtShift.Name = "txtShift";
            this.txtShift.Size = new System.Drawing.Size(100, 20);
            this.txtShift.TabIndex = 4;
            // 
            // lblShiftError
            // 
            this.lblShiftError.AutoSize = true;
            this.lblShiftError.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShiftError.ForeColor = System.Drawing.Color.Red;
            this.lblShiftError.Location = new System.Drawing.Point(494, 48);
            this.lblShiftError.Name = "lblShiftError";
            this.lblShiftError.Size = new System.Drawing.Size(33, 13);
            this.lblShiftError.TabIndex = 5;
            this.lblShiftError.Text = "error";
            // 
            // DecoderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 184);
            this.Controls.Add(this.lblShiftError);
            this.Controls.Add(this.txtShift);
            this.Controls.Add(this.lblShift);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.lblOutputError);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.lblInputError);
            this.Controls.Add(this.lblInput);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnEncode);
            this.Name = "DecoderForm";
            this.Text = "Decoder Ring";
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnEncode;
        private System.Windows.Forms.Label lblShiftError;
        private System.Windows.Forms.TextBox txtShift;
        private System.Windows.Forms.Label lblShift;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label lblOutputError;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.Label lblInputError;
    }
}

